=========
Purpose & Scope:
The obstacle-data-converter is developed as a comandline tool and is used to convert AIXM 5.1(.1) data into an Excel spreadsheet.
The tool is part of the EUROCONTROL Terrain and Obstacle Data Manual, Edition 2.3.

=========
Execution (for Windows):
The 'obstacle-data-converter.bat', contained in the 'bin' folder, has to be called via the command line (e.g. cmd) followed by the AIXMBasicMessage input file that shall be converted.
Step-by-step instruction:
1. Open a command line (e.g. Windows R/cmd).
2. Change directory to the location of the 'bin' folder within the 'obs-data-converter' folder (e.g. cd Documents\obs-data-converter-1.1\bin).
3. Type 'obs-data-converter' to call the corresponding bat file, followed by blank.
4. Type the path to the AIXMBasicMessage file and the file name (e.g. if it is in 'obs-data-converter' folder enter '..\EA_OBS_DS_AERA1_FULL_20191205.xml').
5. Press Enter (executes the conversion).
The converted Excel spreadsheet (xlsx) is stored within the same folder and with the same name as the AIXMBasicMessage input file.
=========

Supported AIXM Version: 5.1, 5.1.1
Supported AIXM Applciation: AIXMBasicMessage
Software requirements: Java JRE 8
OS: Windows, macOS, Linux

========
AIXM 5.1.1 to Spreadsheet Mapping:

**Metadata**
MD_DataIdentification/citation/CI_Citation/title -> Data Set
MD_DataIdentification/extent/EX_Extent/temporalExtent/extent/TimePeriod/beginPosition -> Validity Start Date (Effective Date)
MD_DataIdentification/extent/EX_Extent/temporalExtent/extent/TimePeriod/endPosition -> Validity End Date

**VerticalStructure**
for BASELINE & TEMPDELTA: VerticalStructure.timeSlice.VerticalStructureTimeSlice.validTime.begingPosition  -> Effective date
for PERMDELTA & SNAPSHOT: VerticalStructure.timeSlice.VerticalStructureTimeSlice.validTime.timeInstant -> Effective date
VerticalStrcuture.name --> Obstacle designator/name
VerticalStructure.type --> Obstacle type
VerticalStructure.lighted --> Lighting
VerticalStructure.annotation/../note --> Marking
	IF VerticalStructure.markingICAOStandard = 'YES' than 'YES';
	IF  VerticalStructure.annotation.Note with 
	purpose=�REMARK�
	translatedNote.LinguisticNote.note=�marked=YES� (non-cases senitive)
	propertyName=markingICAOStandard then "YES";
	IF VerticalStructurePart.markingPattern = 'YES' than 'YES';
	IF VerticalStructurePart.markingFirstColour = 'any value' ' than 'YES';
	IF VerticalStructurePart.markingSecondColour = 'any value' ' than 'YES';
	ELSE  leave  cell empty.
VerticalStructure.radius --> Horizontal extent [radius]
VerticalStructure.radius.@uom --> Horizontal extent [uom]
VerticalStructurePart.designator --> Obstacle identifier [part]
VerticalStructurePart/../horizonalPojection -> Geometry type 
	_location --> Geometry type = 'Point'
	_linearExtent --> Geometry type = 'Line'
	_surfaceExtent --> Geometry type = 'Polygon'
VerticalStructurePart/../gml.pos --> Horizontal position
OR VerticalStructurePart/../gml.posList --> Horizontal position
VerticalStructurePart/../elevation --> Elevation
VerticalStructurePart/../elevation.@uom --> Elevation [uom]
VerticalStrucurePart.verticalExtent --> Height
VerticalStrucurePart.verticalExtent@uom --> Height [uom]
VerticalStructurePart.type --> Obstacle type [part]
VerticalStrucurePart.mobile --> Mobile
VerticalStructurePart.lighting.LightElement.type --> Lighting type
VerticalStructurePart.lighting.LightElement.colour --> Lighting colour

